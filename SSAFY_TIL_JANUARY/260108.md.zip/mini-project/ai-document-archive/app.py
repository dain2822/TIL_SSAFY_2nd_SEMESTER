import streamlit as st
import torch
from sentence_transformers import SentenceTransformer
from transformers import (
    AutoModelForImageClassification, AutoProcessor, 
    AutoTokenizer, AutoModelForSeq2SeqLM,
    VisionEncoderDecoderModel, LayoutLMv3Processor, LayoutLMv3ForTokenClassification,
)
from paddleocr import PaddleOCR
from sqlmodel import Field, Session, SQLModel, create_engine, select
from datetime import datetime
from PIL import Image, ExifTags
import io
import base64
import numpy as np
import cv2
from typing import Optional
import json
import re
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from konlpy.tag import Okt
from collections import Counter

# 데이터베이스 모델
class Document(SQLModel, table=True):
    __table_args__ = {'extend_existing': True}
    id: Optional[int] = Field(default=None, primary_key=True)
    filename: str
    doc_type: str
    content: str
    summary: str
    keywords: str
    structured_data: str
    upload_date: datetime = Field(default_factory=datetime.now)
    image_data: bytes
    embedding: Optional[str] = None

# 데이터베이스 초기화
engine = create_engine("sqlite:///archive.db")
SQLModel.metadata.create_all(engine)

# 모델 로드
@st.cache_resource
def load_models():
    dit_processor = AutoProcessor.from_pretrained("microsoft/dit-base-finetuned-rvlcdip")
    dit_model = AutoModelForImageClassification.from_pretrained("microsoft/dit-base-finetuned-rvlcdip")
    
    ocr = PaddleOCR(lang='korean')
    
    donut_processor = AutoProcessor.from_pretrained("naver-clova-ix/donut-base-finetuned-cord-v2")
    donut_model = VisionEncoderDecoderModel.from_pretrained("naver-clova-ix/donut-base-finetuned-cord-v2")
    
    layout_processor = LayoutLMv3Processor.from_pretrained("microsoft/layoutlmv3-base", apply_ocr=False)
    layout_model = LayoutLMv3ForTokenClassification.from_pretrained("microsoft/layoutlmv3-base")
    
    summarizer_tokenizer = AutoTokenizer.from_pretrained("gogamza/kobart-summarization")
    summarizer_model = AutoModelForSeq2SeqLM.from_pretrained("gogamza/kobart-summarization")
    
    embedding_model = SentenceTransformer("jhgan/ko-sroberta-multitask")
    
    okt = Okt()
    
    # 객체 탐지 모델 (YOLO 또는 DETR)
    try:
        from transformers import DetrImageProcessor, DetrForObjectDetection
        object_processor = DetrImageProcessor.from_pretrained("facebook/detr-resnet-50")
        object_model = DetrForObjectDetection.from_pretrained("facebook/detr-resnet-50")
    except:
        object_processor = None
        object_model = None
    
    return (dit_processor, dit_model, ocr, donut_processor, donut_model, 
            layout_processor, layout_model, summarizer_tokenizer, summarizer_model,
            embedding_model, okt, object_processor, object_model)

# 문서 유형 분류
def classify_document(image, dit_processor, dit_model):
    inputs = dit_processor(images=image, return_tensors="pt")
    outputs = dit_model(**inputs)
    predicted_class_idx = outputs.logits.argmax(-1).item()
    predicted_class = dit_model.config.id2label[predicted_class_idx]
    
    if any(keyword in predicted_class.lower() for keyword in ['invoice']):
        return "영수증"
    return predicted_class

# 사진 메타데이터 추출
def extract_photo_metadata(image):
    """사진에서 EXIF 메타데이터 추출"""
    metadata = {}
    
    try:
        exif_data = image._getexif()
        
        if exif_data:
            for tag_id, value in exif_data.items():
                tag = ExifTags.TAGS.get(tag_id, tag_id)
                
                # 주요 정보 추출
                if tag == "DateTime":
                    metadata['taken_date'] = value
                elif tag == "DateTimeOriginal":
                    metadata['original_date'] = value
                elif tag == "Make":
                    metadata['camera_make'] = value
                elif tag == "Model":
                    metadata['camera_model'] = value
                elif tag == "GPSInfo":
                    metadata['gps_info'] = value
                elif tag == "Orientation":
                    metadata['orientation'] = value
                elif tag == "XResolution":
                    metadata['x_resolution'] = value
                elif tag == "YResolution":
                    metadata['y_resolution'] = value
    except:
        pass
    
    # GPS 좌표 변환
    if 'gps_info' in metadata:
        try:
            gps_info = metadata['gps_info']
            lat = convert_gps_to_degrees(gps_info.get(2))
            lon = convert_gps_to_degrees(gps_info.get(4))
            
            if lat and lon:
                lat_ref = gps_info.get(1, 'N')
                lon_ref = gps_info.get(3, 'E')
                
                if lat_ref == 'S':
                    lat = -lat
                if lon_ref == 'W':
                    lon = -lon
                
                metadata['location'] = {'lat': lat, 'lon': lon}
        except:
            pass
    
    return metadata

def convert_gps_to_degrees(gps_coord):
    """GPS 좌표를 도(degree) 형식으로 변환"""
    if not gps_coord:
        return None
    
    try:
        d, m, s = gps_coord
        return float(d) + float(m) / 60 + float(s) / 3600
    except:
        return None

# 객체 탐지
def detect_photo_objects(image, processor, model):
    """사진 내 객체 탐지"""
    if processor is None or model is None:
        return []
    
    try:
        inputs = processor(images=image, return_tensors="pt")
        outputs = model(**inputs)
        
        # 결과 처리
        target_sizes = torch.tensor([image.size[::-1]])
        results = processor.post_process_object_detection(
            outputs, 
            target_sizes=target_sizes, 
            threshold=0.7
        )[0]
        
        detected_objects = []
        for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
            label_name = model.config.id2label[label.item()]
            detected_objects.append({
                'label': label_name,
                'confidence': score.item(),
                'box': box.tolist()
            })
        
        return detected_objects
    except:
        return []

# 사진 키워드 생성
def generate_photo_keywords(metadata, objects):
    """사진 메타데이터와 객체로 키워드 생성"""
    keywords = []
    
    # 날짜 키워드 추가
    if 'taken_date' in metadata:
        try:
            date_str = metadata['taken_date']
            keywords.append(date_str.split()[0])
        except:
            pass
    
    # 카메라 정보 추가
    if 'camera_model' in metadata:
        keywords.append(metadata['camera_model'])
    
    # 탐지된 객체 추가
    if objects:
        object_labels = [obj['label'] for obj in objects[:5]]
        keywords.extend(object_labels)
    
    # 위치 정보 추가
    if 'location' in metadata:
        address = reverse_geocoding(metadata['location'])
        if address:
            keywords.append(address)
    
    return keywords

def reverse_geocoding(location):
    """GPS 좌표를 주소로 변환 (간단한 버전)"""
    try:
        lat = location['lat']
        lon = location['lon']
        return f"위도:{lat:.2f}, 경도:{lon:.2f}"
    except:
        return None

def is_photo(image, metadata, content):
    """이미지가 사진인지 문서인지 판단"""
    # EXIF 데이터가 있으면 사진
    if metadata and ('camera_model' in metadata or 'taken_date' in metadata):
        return True
    
    # OCR 텍스트가 거의 없으면 사진
    if len(content.strip()) < 20:
        return True
    
    return False
def extract_receipt_info(image, processor, model):
    pixel_values = processor(image, return_tensors="pt").pixel_values
    decoder_input_ids = processor.tokenizer("<s_cord-v2>", return_tensors="pt").input_ids
    
    outputs = model.generate(pixel_values, decoder_input_ids=decoder_input_ids, max_length=512)
    prediction = processor.batch_decode(outputs, skip_special_tokens=True)[0]
    
    try:
        receipt_data = json.loads(prediction)
        return receipt_data
    except:
        return {}

# 전처리 (개선된 버전)
def preprocess_image_for_ocr(image):
    """OCR 성능 향상을 위한 적응형 이미지 전처리"""
    
    image = np.array(image)
    original = image.copy()

    # 1. 그레이스케일 변환
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # 2. 이미지 품질 분석
    contrast = gray.std()
    brightness = gray.mean()
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    
    # 3. 조건부 전처리 적용
    processed = gray.copy()
    
    # 3-1. 노이즈 제거 (선명도가 매우 낮을 때만)
    if laplacian_var < 100:
        processed = cv2.fastNlMeansDenoising(processed, None, h=10, templateWindowSize=7, searchWindowSize=21)
    
    # 3-2. 대비 개선 (대비가 낮을 때만)
    if contrast < 50:
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        processed = clahe.apply(processed)
    
    # 3-3. 밝기 조정 (너무 어둡거나 밝을 때)
    if brightness < 80:
        processed = cv2.convertScaleAbs(processed, alpha=1.3, beta=30)
    elif brightness > 200:
        processed = cv2.convertScaleAbs(processed, alpha=0.8, beta=-20)
    
    # 3-4. 이진화는 대비가 매우 낮을 때만 적용
    if contrast < 30:
        processed = cv2.adaptiveThreshold(
            processed, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 
            blockSize=15,
            C=8
        )
    
    # 4. 텍스트 영역 강조
    if laplacian_var < 200:
        kernel = np.array([[-1,-1,-1],
                          [-1, 9,-1],
                          [-1,-1,-1]])
        processed = cv2.filter2D(processed, -1, kernel)
        processed = np.clip(processed, 0, 255).astype(np.uint8)
    
    return processed, cv2.cvtColor(processed, cv2.COLOR_GRAY2BGR)

def perform_ocr(image, ocr_engine):
    image = np.array(image)
    return ocr_engine.ocr(image, cls=True)

def extract_text_and_positions(ocr_result):
    if not ocr_result or not ocr_result[0]:
        return "", []

    full_text = []
    boxes = []

    for line in ocr_result[0]:
        box = line[0]
        text = line[1][0]
        full_text.append(text)
        boxes.append(box)

    return " ".join(full_text), boxes

def get_average_confidence(ocr_result):
    """OCR 결과의 평균 신뢰도 계산"""
    if not ocr_result or not ocr_result[0]:
        return 0.0
    
    confidences = []
    for line in ocr_result[0]:
        if len(line) > 1 and len(line[1]) > 1:
            confidences.append(line[1][1])
    
    return sum(confidences) / len(confidences) if confidences else 0.0

# 일반 OCR
def extract_text_with_layout(image, ocr, use_preprocessing=True):
    original = image

    if use_preprocessing:
        # 원본 이미지 시도
        original_result = ocr.ocr(np.array(image), cls=True)
        
        # 전처리된 이미지 시도
        ocr_image, processed_display = preprocess_image_for_ocr(image)
        processed_result = ocr.ocr(ocr_image, cls=True)
        
        # 비교해서 더 좋은 결과 선택
        original_conf = get_average_confidence(original_result)
        processed_conf = get_average_confidence(processed_result)
        
        if original_conf >= processed_conf:
            result = original_result
            image = np.array(image)
        else:
            result = processed_result
            image = processed_display
    else:
        ocr_image = np.array(image)
        image = ocr_image
        result = ocr.ocr(ocr_image, cls=True)

    text = ""
    boxes = []
    if result and result[0]:
        for line in result[0]:
            text += line[1][0] + " "
            boxes.append(line[0])

    return text.strip(), boxes, original, image

# LayoutLMv3를 활용한 구조화된 정보 추출 함수
def extract_structured_with_layoutlm(image, text, boxes, layout_processor, layout_model, doc_type):
    words = text.split()
    
    if not words:
        return {}
    
    if not boxes or len(boxes) == 0:
        if doc_type == "영수증":
            return {"텍스트": text}
        else:
            return {"내용": text}
    
    if len(boxes) < len(words):
        boxes = boxes + [boxes[-1]] * (len(words) - len(boxes))
    
    width, height = image.size
    normalized_boxes = []
    word_positions = []
    
    for idx, box in enumerate(boxes[:len(words)]):
        if len(box) >= 4:
            x1, y1 = box[0]
            x2, y2 = box[2]
            norm_box = [
                int(x1 * 1000 / width),
                int(y1 * 1000 / height),
                int(x2 * 1000 / width),
                int(y2 * 1000 / height)
            ]
            normalized_boxes.append(norm_box)
            
            word_positions.append({
                'word': words[idx] if idx < len(words) else '',
                'x_center': (norm_box[0] + norm_box[2]) / 2,
                'y_center': (norm_box[1] + norm_box[3]) / 2,
                'width': norm_box[2] - norm_box[0],
                'height': norm_box[3] - norm_box[1],
                'area': (norm_box[2] - norm_box[0]) * (norm_box[3] - norm_box[1])
            })
    
    encoding = layout_processor(
        image,
        words[:len(normalized_boxes)],
        boxes=normalized_boxes,
        return_tensors="pt",
        truncation=True,
        padding="max_length",
        max_length=512
    )
    
    with torch.no_grad():
        outputs = layout_model(**encoding, output_hidden_states=True)
    
    last_hidden_states = outputs.hidden_states[-1]
    
    if doc_type == "영수증":
        structured_data = extract_receipt_structure(word_positions, words, last_hidden_states)
    else:
        structured_data = extract_document_structure(word_positions, words, last_hidden_states)
    
    return structured_data

def extract_receipt_structure(word_positions, words, embeddings):
    structured_data = {
        "상호명": None,
        "날짜": None,
        "시간": None,
        "품목": [],
        "금액": [],
        "합계": None,
        "주소": None,
        "전화번호": None,
        "사업자번호": None
    }
    
    top_words = []
    middle_words = []
    bottom_words = []
    
    for pos in word_positions:
        if pos['y_center'] < 200:
            top_words.append(pos)
        elif pos['y_center'] < 800:
            middle_words.append(pos)
        else:
            bottom_words.append(pos)
    
    if top_words:
        largest = max(top_words, key=lambda x: x['area'])
        structured_data["상호명"] = largest['word']
    
    for pos in word_positions:
        word = pos['word']
        date_match = re.search(r'(\d{4})[.-](\d{1,2})[.-](\d{1,2})', word)
        if date_match:
            structured_data["날짜"] = word
        
        time_match = re.search(r'(\d{1,2}):(\d{2})', word)
        if time_match:
            structured_data["시간"] = word
    
    amount_pattern = r'[\d,]+원?'
    for pos in middle_words:
        word = pos['word']
        if re.match(amount_pattern, word) and pos['x_center'] > 500:
            cleaned_amount = re.sub(r'[^\d]', '', word)
            if cleaned_amount and cleaned_amount.isdigit():
                structured_data["금액"].append(cleaned_amount)
    
    for pos in middle_words:
        word = pos['word']
        if pos['x_center'] < 500 and not re.match(r'[\d,]+', word):
            structured_data["품목"].append(word)
    
    total_candidates = []
    for pos in bottom_words:
        word = pos['word']
        if '합계' in word or '총' in word:
            idx = word_positions.index(pos)
            for i in range(max(0, idx-3), min(len(word_positions), idx+4)):
                nearby_word = word_positions[i]['word']
                if re.match(r'[\d,]+원?', nearby_word):
                    cleaned_amount = re.sub(r'[^\d]', '', nearby_word)
                    if cleaned_amount and cleaned_amount.isdigit():
                        amount = int(cleaned_amount)
                        total_candidates.append(amount)
    
    if total_candidates:
        structured_data["합계"] = str(max(total_candidates))
    elif structured_data["금액"]:
        try:
            amounts = []
            for x in structured_data["금액"]:
                if x.isdigit():
                    amounts.append(int(x))
            if amounts:
                structured_data["합계"] = str(max(amounts))
        except (ValueError, AttributeError):
            pass
    
    for word in words:
        business_match = re.search(r'\d{3}-\d{2}-\d{5}', word)
        if business_match:
            structured_data["사업자번호"] = business_match.group()
    
    for word in words:
        phone_match = re.search(r'(\d{2,3})-(\d{3,4})-(\d{4})', word)
        if phone_match:
            structured_data["전화번호"] = phone_match.group()
    
    structured_data = {k: v for k, v in structured_data.items() if v}
    
    return structured_data

def extract_document_structure(word_positions, words, embeddings):
    structured_data = {
        "제목": None,
        "부제목": [],
        "날짜": None,
        "작성자": None,
        "핵심내용": [],
        "번호정보": []
    }
    
    top_words = [pos for pos in word_positions if pos['y_center'] < 200]
    if top_words:
        largest = max(top_words, key=lambda x: x['area'])
        structured_data["제목"] = largest['word']
    
    avg_area = sum(pos['area'] for pos in word_positions) / len(word_positions)
    for pos in word_positions:
        if pos['area'] > avg_area * 1.5 and pos['word'] != structured_data.get("제목"):
            structured_data["부제목"].append(pos['word'])
    
    for word in words:
        date_match = re.search(r'(\d{4})[.-](\d{1,2})[.-](\d{1,2})', word)
        if date_match:
            structured_data["날짜"] = date_match.group()
            break
    
    for word in words:
        phone_match = re.search(r'(\d{2,3})-(\d{3,4})-(\d{4})', word)
        if phone_match:
            structured_data["번호정보"].append(f"전화: {phone_match.group()}")
        
        account_match = re.search(r'\d{10,}', word)
        if account_match:
            structured_data["번호정보"].append(f"계좌: {account_match.group()}")
    
    long_texts = []
    current_text = []
    
    for i, word in enumerate(words):
        current_text.append(word)
        if word.endswith('.') or word.endswith('!') or word.endswith('?') or i == len(words) - 1:
            sentence = ' '.join(current_text)
            if len(sentence) > 20:
                long_texts.append(sentence)
            current_text = []
    
    structured_data["핵심내용"] = sorted(long_texts, key=len, reverse=True)[:3]
    
    structured_data = {k: v for k, v in structured_data.items() if v}
    
    return structured_data

def extract_structured_info(text, doc_type):
    structured_data = {}
    
    if doc_type == "영수증":
        date_pattern = r'(\d{4})[.-](\d{1,2})[.-](\d{1,2})'
        date_match = re.search(date_pattern, text)
        if date_match:
            structured_data['date'] = f"{date_match.group(1)}.{date_match.group(2)}.{date_match.group(3)}"
        
        price_pattern = r'([0-9,]+)\s*원'
        prices = re.findall(price_pattern, text)
        if prices:
            structured_data['amounts'] = [p.replace(',', '') for p in prices]
            structured_data['total'] = max([int(p.replace(',', '')) for p in prices])
        
        words = text.split()
        if len(words) > 0:
            structured_data['store'] = words[0]
    
    return structured_data

# 텍스트 요약
def summarize_text(text, tokenizer, model):
    if not text or len(text) < 50:
        return text
    
    inputs = tokenizer(text[:1024], return_tensors="pt", max_length=512, truncation=True)
    summary_ids = model.generate(inputs["input_ids"], max_length=128, min_length=20, num_beams=4)
    summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
    return summary

# 텍스트 임베딩 생성
def create_embedding(text, model):
    if not text or len(text.strip()) < 2:
        return None
    
    embedding = model.encode(text)
    return embedding.tolist()

# 한국어 형태소 분석 및 명사 추출
def morpheme_analyze(text, okt):
    """Konlpy의 Okt를 사용하여 형태소 분석 및 품사 태깅"""
    return okt.pos(text, norm=True, stem=True)

def extract_nouns_from_pos(pos_tagged):
    """품사 태깅된 결과에서 명사만 추출"""
    nouns = []
    for word, pos in pos_tagged:
        if pos in ['Noun', 'ProperNoun']:
            if len(word) > 1:
                nouns.append(word)
    return nouns

def create_compound_nouns(nouns, max_length=3):
    """연속된 명사를 결합하여 복합 명사 생성"""
    compound_nouns = []
    for i in range(len(nouns) - 1):
        compound = nouns[i] + nouns[i+1]
        compound_nouns.append(compound)
        
        if i < len(nouns) - 2 and max_length >= 3:
            compound = nouns[i] + nouns[i+1] + nouns[i+2]
            compound_nouns.append(compound)
    
    return compound_nouns

def calculate_tfidf_scores(words, corpus=None):
    """TF-IDF 점수 계산"""
    if not words:
        return {}
    
    word_counts = Counter(words)
    
    if corpus and len(corpus) > 1:
        try:
            documents = [' '.join(words)] + corpus
            
            vectorizer = TfidfVectorizer()
            tfidf_matrix = vectorizer.fit_transform(documents)
            
            feature_names = vectorizer.get_feature_names_out()
            tfidf_scores = tfidf_matrix[0].toarray()[0]
            
            word_scores = {}
            for word, score in zip(feature_names, tfidf_scores):
                if word in word_counts:
                    word_scores[word] = score
            
            return word_scores
        except:
            pass
    
    max_count = max(word_counts.values()) if word_counts else 1
    word_scores = {word: count / max_count for word, count in word_counts.items()}
    
    return word_scores

def select_top_keywords(word_scores, top_k=15):
    """점수 기준 상위 키워드 선택"""
    if not word_scores:
        return []
    
    sorted_words = sorted(word_scores.items(), key=lambda x: x[1], reverse=True)
    top_keywords = [word for word, score in sorted_words[:top_k]]
    
    return top_keywords

def extract_keywords_with_morpheme_analysis(text, okt, top_k=15, corpus=None):
    """형태소 분석을 통한 키워드 추출"""
    pos_tagged = morpheme_analyze(text, okt)
    nouns = extract_nouns_from_pos(pos_tagged)
    
    if not nouns:
        return []
    
    compound_nouns = create_compound_nouns(nouns)
    all_nouns = nouns + compound_nouns
    
    word_scores = calculate_tfidf_scores(all_nouns, corpus)
    top_keywords = select_top_keywords(word_scores, top_k)
    
    return top_keywords

def extract_structured_keywords(structured_data):
    """구조화된 데이터에서 중요 키워드 추출"""
    keywords = []
    
    if '상호명' in structured_data and structured_data['상호명']:
        keywords.append(structured_data['상호명'])
    
    if '날짜' in structured_data and structured_data['날짜']:
        keywords.append(structured_data['날짜'])
    
    if '품목' in structured_data and structured_data['품목']:
        keywords.extend(structured_data['품목'][:3])
    
    if '제목' in structured_data and structured_data['제목']:
        keywords.append(structured_data['제목'])
    
    if '부제목' in structured_data and structured_data['부제목']:
        keywords.extend(structured_data['부제목'][:2])
    
    if '작성자' in structured_data and structured_data['작성자']:
        keywords.append(structured_data['작성자'])
    
    return keywords

def format_keywords(keywords):
    """키워드 리스트를 문자열로 포맷팅"""
    unique_keywords = []
    seen = set()
    
    for keyword in keywords:
        if keyword and keyword not in seen and len(keyword.strip()) > 0:
            unique_keywords.append(keyword)
            seen.add(keyword)
    
    return ", ".join(unique_keywords)

# 문서 처리
def process_document(uploaded_file, models):
    (dit_processor, dit_model, ocr, donut_processor, donut_model, 
     layout_processor, layout_model, sum_tokenizer, sum_model,
     embedding_model, okt, object_processor, object_model) = models
    
    image = Image.open(uploaded_file).convert("RGB")
    
    # 메타데이터 추출
    metadata = extract_photo_metadata(Image.open(uploaded_file))
    print('\n==========')
    print(f'\n[metadata]\n{metadata}')
    
    # OCR 수행
    content, boxes, original_img, processed_img = extract_text_with_layout(
        image, ocr, use_preprocessing=True
    )
    
    st.session_state["ocr_original_img"] = original_img
    st.session_state["ocr_processed_img"] = processed_img
    
    # 사진 여부 판단
    if is_photo(image, metadata, content):
        print('\n사진으로 판단됨')
        doc_type = "사진"
        
        # 객체 탐지
        objects = detect_photo_objects(image, object_processor, object_model)
        print('\n==========')
        print(f'\n[detected_objects]\n{objects}')
        
        # 키워드 생성
        photo_keywords = generate_photo_keywords(metadata, objects)
        
        # 구조화된 데이터 생성
        structured_data = {
            'metadata': metadata,
            'detected_objects': [obj['label'] for obj in objects[:10]]
        }
        
        # 요약 생성
        if objects:
            object_names = ', '.join([obj['label'] for obj in objects[:5]])
            summary = f"이 사진에는 {object_names} 등이 포함되어 있습니다."
        else:
            summary = "사진입니다."
        
        # 키워드 포맷팅
        keywords = format_keywords(photo_keywords)
    
    else:
        print('\n문서로 판단됨')
        # 기존 문서 처리 로직
        doc_type = classify_document(image, dit_processor, dit_model)
        print('\n==========')
        print(f'\n[doc_type]\n{doc_type}')
        
        layoutlm_data = extract_structured_with_layoutlm(image, content, boxes, layout_processor, layout_model, doc_type)
        print('\n==========')
        print(f'\n[layoutlm_data]\n{layoutlm_data}')
        
        if doc_type == "영수증":
            print('영수증')
            receipt_info = extract_receipt_info(image, donut_processor, donut_model)
            print('\n==========')
            print(f'\n[receipt_info]\n{receipt_info}')
            
            structured_data = extract_structured_info(content, doc_type)
            if receipt_info:
                for key, value in receipt_info.items():
                    if key not in layoutlm_data or not layoutlm_data[key]:
                        layoutlm_data[key] = value
            else:
                structured_data = layoutlm_data
            structured_data.update(receipt_info)
        else:
            structured_data = layoutlm_data

        print('\n==========')
        print(f'\n[content]\n{content}')
        print('\n==========')
        print(f'\n[structured_data]\n{structured_data}')
        
        summary = summarize_text(content, sum_tokenizer, sum_model)
        print('\n==========')
        print(f'\n[summary]\n{summary}')
        
        # 키워드 추출 (형태소 분석 기반)
        text_keywords = extract_keywords_with_morpheme_analysis(content, okt, top_k=10)
        summary_keywords = extract_keywords_with_morpheme_analysis(summary, okt, top_k=5)
        structured_keywords = extract_structured_keywords(structured_data)
        
        all_keywords = text_keywords + summary_keywords + structured_keywords
        keywords = format_keywords(all_keywords)
    
    print('\n==========')
    print(f'\n[keywords]\n{keywords}')
    
    embedding = create_embedding(content + " " + summary, embedding_model)
    
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format='PNG')
    img_data = img_byte_arr.getvalue()
    
    return doc_type, content, summary, keywords, structured_data, img_data, embedding

# 벡터 유사도 검색
def search_by_similarity(query, embedding_model, okt, session):
    query_embedding = create_embedding(query, embedding_model)
    
    all_docs = session.exec(select(Document)).all()
    
    similarities = []
    for doc in all_docs:
        if doc.embedding:
            doc_embedding = json.loads(doc.embedding)
            similarity = cosine_similarity([query_embedding], [doc_embedding])[0][0]
            similarities.append((doc, similarity))
    
    similarities.sort(key=lambda x: x[1], reverse=True)
    return [doc for doc, sim in similarities[:10] if sim > 0.5]
def print_result_list(results):
    for doc in results:
        with st.expander(f"{doc.filename} - {doc.upload_date.strftime('%Y-%m-%d %H:%M')}"):
            col1, col2 = st.columns(2)
            with col1:
                img = Image.open(io.BytesIO(doc.image_data))
                st.image(img, use_container_width=True)
            with col2:
                st.write(f"**문서 유형:** {doc.doc_type}")
                st.write(f"**요약:** {doc.summary}")
                st.write(f"**키워드:** {doc.keywords}")
                
                if doc.structured_data:
                    structured = json.loads(doc.structured_data)
                    if structured:
                        st.write("**추출된 정보:**")
                        for k, v in structured.items():
                            st.write(f"- {k}: {v}")
                
                b64 = base64.b64encode(doc.image_data).decode()
                href = f'<a href="data:image/png;base64,{b64}" download="{doc.filename}">다운로드</a>'
                st.markdown(href, unsafe_allow_html=True)


# Streamlit UI
st.title("AI 아카이브 시스템")

with st.spinner("AI 모델 로딩 중..."):
    models = load_models()

tab1, tab2, tab3 = st.tabs(["문서 업로드", "문서 검색", "문서 목록"])

if 'processed_file' not in st.session_state:
    st.session_state.processed_file = None
if 'processing_complete' not in st.session_state:
    st.session_state.processing_complete = False
if 'doc_results' not in st.session_state:
    st.session_state.doc_results = None

# 문서 업로드 탭
with tab1:
    uploaded_file = st.file_uploader("문서를 업로드하세요", type=['png', 'jpg', 'jpeg'])
    processed_img = st.session_state.get("ocr_processed_img")

    if uploaded_file is not None and uploaded_file != st.session_state.processed_file:
        st.session_state.processed_file = uploaded_file
        st.session_state.processing_complete = False
    
    if uploaded_file is not None and not st.session_state.processing_complete:
        with st.spinner("문서 처리 중..."):
            doc_type, content, summary, keywords, structured_data, img_data, embedding = process_document(
                uploaded_file, models
            )
            st.session_state.processing_complete = True
            st.session_state.doc_results = {
                'doc_type': doc_type,
                'content': content,
                'summary': summary,
                'keywords': keywords,
                'structured_data': structured_data,
                'img_data': img_data,
                'embedding': embedding
            }
    
    if uploaded_file is not None and st.session_state.doc_results is not None:
        results = st.session_state.doc_results

        col1, col2 = st.columns(2)
        with col1:
            st.image(uploaded_file, caption="업로드된 문서", use_container_width=True)

        with col2:
            processed_img = st.session_state.get("ocr_processed_img")
            if processed_img is not None:
                st.image(processed_img, caption="전처리 후 이미지", use_container_width=True)

            st.write(f"**분류 결과:** {results['doc_type']}")
            st.write(f"**요약:** {results['summary']}")
            st.write(f"**키워드:** {results['keywords']}")
            
            if results['doc_type'] == "사진":
                structured = results['structured_data']
                metadata = structured.get('metadata', {})

                # EXIF 정보
                if metadata:
                    st.write("사진 상세 정보 (EXIF)")
                    m_col1, m_col2 = st.columns(2)
                    with m_col1:
                        st.write(f"- 기종: {metadata.get('camera_model', '정보 없음')}")
                    with m_col2:
                        st.write(f"- 일시: {metadata.get('taken_date', '정보 없음')}")

                # 위치 정보 지도 표시
                if 'location' in metadata:
                    st.write("촬영 위치(GPS)")
                    lat, lon = metadata['location']['lat'], metadata['location']['lon']
                    import pandas as pd
                    map_df = pd.DataFrame({'lat': [lat], 'lon': [lon]})
                    st.map(map_df)
                    
                # 객체 표시
                if 'detected_objects' in structured:
                    st.write(f"탐지된 객체: {', '.join(structured['detected_objects'])}")
            
            # 일반 문서인 경우
            elif results['structured_data']:
                st.write("**추출된 정보:**")
                for key, value in results['structured_data'].items():
                    st.write(f"- {key}: {value}")
            
            if st.button("저장"):
                with Session(engine) as session:
                    doc = Document(
                        filename=uploaded_file.name,
                        doc_type=results['doc_type'],
                        content=results['content'],
                        summary=results['summary'],
                        keywords=results['keywords'],
                        structured_data=json.dumps(results['structured_data'], ensure_ascii=False),
                        image_data=results['img_data'],
                        embedding=json.dumps(results['embedding'])
                    )
                    session.add(doc)
                    session.commit()
                st.success("문서가 저장되었습니다!")
                st.session_state.processed_file = None
                st.session_state.processing_complete = False
                st.session_state.doc_results = None

# 문서 검색 탭
with tab2:
    search_query = st.text_input("검색어를 입력하세요 (예: 커피 영수증)")
    search_method = st.radio("검색 방법", ["벡터 유사도 검색", "키워드 검색"])
    
    if st.button("검색", key='search_button'):
        with Session(engine) as session:
            if search_method == "벡터 유사도 검색":
                results = search_by_similarity(search_query, models[9], models[10], session)
            else:
                # 키워드 검색 시 메타데이터 컬럼 포함
                statement = select(Document).where(
                    Document.keywords.contains(search_query) | 
                    Document.summary.contains(search_query) |
                    Document.doc_type.contains(search_query) |
                    Document.structured_data.contains(search_query)
                )
                results = session.exec(statement).all()
            
            if results:
                print_result_list(results)
            else:
                st.info("검색 결과가 없습니다.")

# 문서 목록 탭
with tab3:
    with Session(engine) as session:
        statement = select(Document)
        results = session.exec(statement).all()
        if results:
            print_result_list(results)